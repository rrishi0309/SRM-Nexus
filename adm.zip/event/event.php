<?php

define('IN_PHPBB', true);
$phpbb_root_path = (defined('PHPBB_ROOT_PATH')) ? PHPBB_ROOT_PATH : '../';
$phpEx = substr(strrchr(__FILE__, '.'), 1);
include($phpbb_root_path . 'common.' . $phpEx);
include($phpbb_root_path . 'includes/functions_display.' . $phpEx);

// Start session
$user->session_begin();
$auth->acl($user->data);
$user->setup();
$pop = "Seems like you are not logged in! You will be redirected to the login page! Login and try again :)";
if($user->data['user_id'] == ANONYMOUS)
{
echo "<script type='text/javascript'>alert('$pop');</script>";
header("Location: https://nexus.pixlz.in/event/eventlogin.php?mode=login");

}	
else
{
$id=$user->data['user_id'];
$sql="SELECT count(*) as user_count from phpbb_hacksketch ";

$value=250;
$check= $db->sql_query($sql);
$user_count = (int) $db->sql_fetchfield('user_count');
if($user_count>=$value)
header("Location: https://nexus.pixlz.in/event/sorry.php");
else
{
$sql="INSERT INTO phpbb_hacksketch 
SELECT username_clean, user_birthday , user_email, pf_regno, pf_year, pf_dept, pf_mobile
FROM phpbb_users u1, phpbb_profile_fields_data u2
WHERE u1.user_id= $id 
AND u2.user_id= $id ";

// Perform Query
$result = $db->sql_query($sql);
// Check result
// This shows the actual query sent to MySQL, and the error. Useful for debugging.
if (!$result) {
    $message  = 'Invalid query: ' . mysql_error() . "\n";
    $message .= 'Whole query: ' . $query;
    die($message);
}
header("Location: https://nexus.pixlz.in/event/confirm.php");
die();
}
}
?> 