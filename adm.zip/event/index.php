
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />

		<!-- FAVICON -->
		<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
		<link rel="icon" href="favicon.ico" type="image/x-icon">
		
		<!-- TITLE -->
		<title>Sketch Event | HackThePlanet</title>
		
		<!-- DESCRIPTION -->		
		<meta name="description" content="Hack the planet event" />
		<meta name="keywords"  content="" />
		<meta name="author" content="Pixlz(TM)" />
		<meta name="msapplication-navbutton-color" content="#8038b6">
<meta name="apple-mobile-web-app-status-bar-style" content="#8038b6">
<meta name="theme-color" content="#8038b6">
<meta name="apple-mobile-web-app-status-bar-style" content="#8038b6">
		
		<!-- GOOGLE FONTS -->
	    <link href='http://fonts.googleapis.com/css?family=Raleway:400,700,600,500,300,200,100,800,900' rel='stylesheet' type='text/css'> 
		
		<!-- STYLESHEETS -->
		<link href="assets/css/bootstrap.css" rel="stylesheet">
		<link href="assets/css/font-awesome.min.css" rel="stylesheet" type="text/css">	
		<link href="assets/css/jquery.countdown.css" rel="stylesheet" type="text/css">
		<link href="assets/css/style.css" rel="stylesheet" type="text/css">
	    <link href="assets/css/queries.css" rel="stylesheet" type="text/css">	
		
	 	<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
		<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
		<![endif]-->
	
	</head>
	   
   <body id="top">
	  
		<!--PRELOADER-->
		<div class="preloader">
		<div class="status"></div>
		</div>
		<!--/PRELOADER-->

		
		
		
		
	
		
        <!-- REGISTRATION FORM -->
		<section id="swag" class="swag text-center">
			<div class="container">
				<div class="row">
					<div class="col-lg-9 align-center">
						<form id="nl-form" class="nl-form ">
							Hey There!  
							Sorry The Registrations Have Been Closed :( <br>
							
							
						</form>

						
					</div>
				</div>
			</div>
        </section>
		 <!-- /REGISTRATION FORM -->
        
		<!-- CONTACT -->
		<section class="text-center section-padding contact-wrap" id="contact">
        
			 <!-- /CONTACT -->
			

          
        </section>
		

		<!-- FOOTER -->
		<footer>
          <div class="container">
            <div class="row">
              <div class="col-md-6 align-center">
                <ul class="legals">
					<li><a href=> Built On NEXUS </a></li>
					
					<li><a href="https://pixlz.in">Made with <3 by WebDevTEAM @ Pixlz</a></li>
                </ul>
              </div>
			  
			</div>
			<div class="md-overlay"></div>
            </div>
          </div>
        </footer>
		<!-- /FOOTER -->
		
	</div>
		
		
		<!-- /FOOTER -->
		<!-- SCRIPTS -->
		<script type="text/javascript" src="assets/js/jquery-1.11.0.min.js"></script>
		<script type="text/javascript" src="assets/js/jquery-ui-1.10.4.min.js"></script>
        <script type="text/javascript" src="assets/js/nlform.js"></script>
		<script>var nlform = new NLForm( document.getElementById( 'nl-form' ) );</script>
        <script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
		
		<!-- SMOOTH SCROLL  -->
		<script type="text/javascript" src="assets/js/jquery.nicescroll.js"></script>
		
		<!-- SUBSCRIPTION FORM  -->
		<script type="text/javascript" src="assets/js/notifyMe.js"></script>
		<script type="text/javascript" src="assets/js/jquery.plugin.js"></script>
		<script type="text/javascript" src="assets/js/modernizr.custom.js"></script>
		
		<!--COUNTER-->
		<script type="text/javascript" src="assets/js/jquery.countdown.js"></script>
		
		<!-- SUBSCRIPTION FORM PLACEHOLDER -->
		<script type="text/javascript" src="assets/js/jquery.placeholder.js"></script>
		<script type="text/javascript" src="assets/js/modalEffects.js"></script>
		<script type="text/javascript" src="assets/js/classie.js"></script>
		
		<!-- INITIALIZATION  -->
		<script type="text/javascript" src="assets/js/init.js" ></script>
		<!--particles-->				
		<script type="text/javascript" src="assets/js/jquery.particleground.min.js"></script>
		<script type="text/javascript" src="assets/js/astronomy-init.js"></script>
    </body>
</html>