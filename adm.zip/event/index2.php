<?php

define('IN_PHPBB', true);
$phpbb_root_path = (defined('PHPBB_ROOT_PATH')) ? PHPBB_ROOT_PATH : '../';
$phpEx = substr(strrchr(__FILE__, '.'), 1);
include($phpbb_root_path . 'common.' . $phpEx);
include($phpbb_root_path . 'includes/functions_display.' . $phpEx);

// Start session
$user->session_begin();
$auth->acl($user->data);
$user->setup('viewforum');
?>


<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />

		<!-- FAVICON -->
		<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
		<link rel="icon" href="favicon.ico" type="image/x-icon">
		
		<!-- TITLE -->
		<title>Sketch Event | HackThePlanet</title>
		
		<!-- DESCRIPTION -->		
		<meta name="description" content="Hack the planet event" />
		<meta name="keywords"  content="" />
		<meta name="author" content="Pixlz(TM)" />
		<meta name="msapplication-navbutton-color" content="#8038b6">
<meta name="apple-mobile-web-app-status-bar-style" content="#8038b6">
<meta name="theme-color" content="#8038b6">
<meta name="apple-mobile-web-app-status-bar-style" content="#8038b6">
		
		<!-- GOOGLE FONTS -->
	    <link href='http://fonts.googleapis.com/css?family=Raleway:400,700,600,500,300,200,100,800,900' rel='stylesheet' type='text/css'> 
		
		<!-- STYLESHEETS -->
		<link href="assets/css/bootstrap.css" rel="stylesheet">
		<link href="assets/css/font-awesome.min.css" rel="stylesheet" type="text/css">	
		<link href="assets/css/jquery.countdown.css" rel="stylesheet" type="text/css">
		<link href="assets/css/style.css" rel="stylesheet" type="text/css">
	    <link href="assets/css/queries.css" rel="stylesheet" type="text/css">	
		
	 	<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
		<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
		<![endif]-->
	

	</head>
	   
   <body id="top">
   	<script type="text/javascript" src="assets/js/modalEffects.js"></script>
     
        <script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
	  <div id="myModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
     You are signed in now!
    </div>
  </div>
</div>
		<!--PRELOADER-->
		<div class="preloader">
		<div class="status"></div>
		</div>
		<!--/PRELOADER-->

		
		<section id="sec_1" class="autoheight">
		<div class="home-bg"></div>
		<div id="particles"></div>
			
		</section>
		
        <!-- REGISTRATION FORM -->
		<section id="swag" class="swag text-center">
			<div class="container">
				<div class="row">
					<div class="col-lg-9 align-center">
						<form id="nl-form" class="nl-form " action="event.php">
							Hey There Padawan! Register for the event here by hitting the register button. Make sure you are logged in to SRM NEXUS!
							May the force be with you.							
							<div class="nl-submit-wrap">
								<button  class="nl-submit btn-effect" type="submit" id="submit_btn">Register</button>
							</div>				
							<div id="result"></div>
							<div class="nl-overlay"></div>
						</form>

						<div class="md-modal md-effect-10" id="terms_conditions">
							<div class="md-content">
								<div class="tnc-folio">
									<h3>Terms and Conditions</h3>
									<div>
										<ul>
											<li>The club or its members aren't responsible for any problem.</li>
											<li>The event is only for educational purpose, we dont entertain using again someone.</li>
											<li>Hacking is considered a cyber crime and we arent responsible for your actions.</li>
										</ul>
										<button class="md-close"><i class="fa fa-times"></i></button>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-12 tc">Please read the<button class="md-trigger" data-modal="terms_conditions">Terms & Conditions</button>carefully.</div>
						<!-- the overlay element -->
						<div class="md-overlay"></div>
					</div>
				</div>
			</div>
        </section>
		 <!-- /REGISTRATION FORM -->
        
		<!-- CONTACT -->
		<section class="text-center section-padding contact-wrap" id="contact">
          <div class="container">
				<div class="row">
					<div class="col-md-8 wow animated fadeInLeft align-center" data-wow-duration="1s" data-wow-delay="0.3s">
						<h1 class="arrow">Event Details</h1><hr>
						<p>Hack The Planet, is an event by SRM Sketch Club. In this event we will have some live demonstations and teach you some stuffs about hacking and help you be safe </p>
					</div>
				</div>
				<div class="row contact-details">
					<div class="col-md-4 wow animated fadeInDown" data-wow-duration="1s" data-wow-delay="0.5s">
						<div class="light-box box-hover">
							<h2><span>Intro to ethical hacking</span></h2>
							<p>blah blah blah</p>
						</div>
					</div>
					<div class="col-md-4 wow animated fadeInDown" data-wow-duration="1s" data-wow-delay="0.7s">
						<div class="light-box box-hover">
							<h2><span>Attacks and how they are done</span></h2>
							<p>Cher. k. bye.</p>
						</div>
					</div>
					<div class="col-md-4 wow animated fadeInDown" data-wow-duration="1s" data-wow-delay="0.9s">
						<div class="light-box box-hover">
							<h2><span>How safe are you ?</span></h2>
							<p>*seenzoned*</p>
						</div>
					</div>
				</div>
				<div class="row">
					<a id="get_directions" class="learn-more-btn btn-effect" href="https://nexus.pixlz.in/sketch"><i class="fa fa-code"></i><span>View on NEXUS</span></a>
				</div>
			 <!-- /CONTACT -->
			

          </div>
        </section>
		

		<!-- FOOTER -->
		<footer>
          <div class="container">
            <div class="row">
              <div class="col-md-6 align-center">
                <ul class="legals">
					<li><a href="https://nexus.pixlz.in"> Built On NEXUS </a></li>
					
					<li><a href="https://pixlz.in">Made with <3 by WebDevTEAM @ Pixlz</a></li>
                </ul>
              </div>
			  
			</div>
			<div class="md-overlay"></div>
            </div>
          </div>
        </footer>
		<!-- /FOOTER -->
		
	</div>
		
		
		<!-- /FOOTER -->
				<!-- SCRIPTS -->
		<script type="text/javascript" src="assets/js/jquery-1.11.0.min.js"></script>
		<script type="text/javascript" src="assets/js/jquery-ui-1.10.4.min.js"></script>
		
		
		<!-- SMOOTH SCROLL  -->
		
		<script type="text/javascript" src="assets/js/jquery.nicescroll.js"></script>
		<script type="text/javascript" src="assets/js/perfect-scrollbar.min.js"></script>
		
		
		<!-- SUBSCRIPTION FORM  -->
		<script type="text/javascript" src="assets/js/notifyMe.js"></script>
		<script type="text/javascript" src="assets/js/jquery.plugin.js"></script>
		<script type="text/javascript" src="assets/js/modernizr.custom.js"></script>
		
		<!--COUNTER-->
		<script type="text/javascript" src="assets/js/jquery.countdown.js"></script>
		
		<!-- SUBSCRIPTION FORM PLACEHOLDER -->
		<script type="text/javascript" src="assets/js/jquery.placeholder.js"></script>
		
		<script type="text/javascript" src="assets/js/classie.js"></script>
		
		<!-- INITIALIZATION  -->
		<script type="text/javascript" src="assets/js/init.js" ></script>
		<!--particles-->				
		<script type="text/javascript" src="assets/js/jquery.particleground.min.js"></script>
		<script type="text/javascript" src="assets/js/astronomy-init.js"></script>
    </body>
</html>