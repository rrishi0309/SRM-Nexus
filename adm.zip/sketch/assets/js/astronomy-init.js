jQuery(window).load(function() {
	 jQuery('#particles').particleground({
		dotColor: '#919191',
		lineColor: '#919191',
		lineWidth: '0.51',
		particleRadius: '3'
	  });
});