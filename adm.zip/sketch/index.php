<?php

define('IN_PHPBB', true);
$phpbb_root_path = (defined('PHPBB_ROOT_PATH')) ? PHPBB_ROOT_PATH : '../';
$phpEx = substr(strrchr(__FILE__, '.'), 1);
include($phpbb_root_path . 'common.' . $phpEx);
include($phpbb_root_path . 'includes/functions_display.' . $phpEx);

// Start session
$user->session_begin();
$auth->acl($user->data);
$user->setup('viewforum');
?>

 <!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />

		<!-- FAVICON -->
		<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
		<link rel="icon" href="favicon.ico" type="image/x-icon">
		
		<!-- TITLE -->
		<title>MiEvent</title>
		
		<!-- DESCRIPTION -->
		<meta name="author" content=" " />
		<meta name="description" content="" />
		<meta name="keywords"  content="" />

		<!-- GOOGLE FONTS -->
		<link href='http://fonts.googleapis.com/css?family=Raleway:400,700,600,500,300,200,100,800,900' rel='stylesheet' type='text/css'> 

		<!-- STYLESHEETS -->
		<link href="assets/css/bootstrap.css" rel="stylesheet">
		<link href="assets/css/panel.css" rel="stylesheet" type="text/css" />
		<link href="assets/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
		<link href="assets/css/flexslider.css" rel="stylesheet" >
		<link href="assets/css/animate.css" rel="stylesheet">
		<link href="assets/css/schedule.css" rel="stylesheet">
		<link href="assets/css/gridgallery.css" rel="stylesheet" type="text/css"  />
		<link href="assets/css/venobox.css" rel="stylesheet" type="text/css"/>
		<link href="assets/css/style.css" rel="stylesheet"/>
		<link href="assets/css/queries.css" rel="stylesheet"/>
	  
		<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
		<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
		<![endif]-->
	
	</head>
	   
   <body id="top" data-spy="scroll" data-target=".header" data-offset="80">
	  
		<!--PRELOADER-->
		<div class="preloader">
		<div class="status"></div>
		</div>
		<!--/PRELOADER-->

		<!--HEADER-->
	  	<div class="header header-hide">
			<div class="container">
				<nav class="navbar navbar-default" role="navigation">
				   <div class="navbar-header">
					  <button type="button" class="navbar-toggle" data-toggle="collapse" 
						 data-target="#example-navbar-collapse">
						 <span class="sr-only">Toggle navigation</span>
						 <span class="icon-bar"></span>
						 <span class="icon-bar"></span>
						 <span class="icon-bar"></span>
					  </button>
					   <a class="navbar-brand" data-scroll href="#sec_1"><img src="assets/img/logo.png" alt="logo"/></a>
				   </div>
				   <div class="collapse navbar-collapse" id="example-navbar-collapse">
					  <ul class="nav navbar-nav">
						<li><a data-scroll href="#intro">About</a></li>
						
						<li><a data-scroll href="#sponsers">Sponsors</a></li>
						<li><a data-scroll href="#contact">Contact</a></li>
						<li class="hidden"><a href="#sec_1">Home</a></li>
					  </ul>
				   </div>
				</nav>
			</div>
		</div>
		<!--/HEADER-->
		
		<!--HOME-->		
		<section id="sec_1" class="autoheight">
			<div class="home-bg"></div>
			<div class="col-lg-12 landing-text-pos align-center">
				<h1 class="wow animated fadeInDown" data-wow-duration="1s" data-wow-delay="1s">Sketch Event</h1>
				<hr id="title_hr"/>
				<p class="wow animated fadeInUp" data-wow-duration="1s" data-wow-delay="1s">OP Block,1st Floor, Seminar Hall 22 Sept 2017</p>
				<form id="nl-form" class="nl-form " action="event.php">
											
							<div class="nl-submit-wrap">
								<button  class="nl-submit btn-effect" type="submit" id="submit_btn">Register</button>
							</div>				
							<div id="result"></div>
							<div class="nl-overlay"></div>
						</form>
			</div>
		</section>
		<!--/HOME-->
		
		<!--ABOUT-->	
        <section class="intro text-center section-padding" id="intro">
			<div class="container wow animated fadeInLeft animated" data-wow-duration="1s" data-wow-delay="0.5s">
				<div class="row">
					<div class="col-lg-8 align-center about">
						<h1 class="arrow">About Sketch</h1>
						<hr>
						<p> Sketch Pixlz edition is one of the clubs which aims at the design of the application rather than the application itself. Here we design, develop and deliver. A place where the fresh minds collaborate to the changing trends in technology.</p>
					</div>
				</div>
			</div>
        </section>
		
		<!--/ABOUT-->
		   <!--FEATURES-->	
        <section class="intro text-center section-padding" id="features">
		<div class="container">
		<div class="col-md-6">
		
		
		<div class="embed-responsive embed-responsive-4by3">
    <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/AeM1oWmHzpk"  allowfullscreen></iframe>
</div>
</div>
<div class="col-md-6">
</div>
		<div class="col-md-6">
		<div class="embed-responsive embed-responsive-4by3">
    <iframe class="embed-responsive-item" src=" https://www.youtube.com/embed/DqbXS7Fgby0"  allowfullscreen></iframe>
</div>
		</div>
		</div>
					</section>
					<!--grid wrap-->

			



  
		

        
    

      


		<!--CONTACT-->	
        <section class="text-center section-padding contact-wrap" id="contact">
			<div class="container">
				<div class="row">
					<div class="col-md-8 wow animated fadeInLeft align-center" data-wow-duration="1s" data-wow-delay="0.3s">
						<h1 class="arrow">Contact</h1><hr>
						<p>You can reach out to us if you have any clarifications or issues with event registration</p>
					</div>
				</div>
				<div class="row contact-details">
					<div class="col-md-4 wow animated fadeInDown" data-wow-duration="1s" data-wow-delay="0.5s">
						<div class="light-box box-hover">
							<h2><span>Registration Info</span></h2>
							<p>Click on the register button. <br> You will be redirected to SRM Nexus Login Page.<br>If you are not a registered user then kindly register and try again.</p>
						</div>
					</div>
					<div class="col-md-4 wow animated fadeInDown" data-wow-duration="1s" data-wow-delay="0.7s">
						<div class="light-box box-hover">
							<h2><span>Your privacy matters</span></h2>
							<p>Your details in the nexus database<br>will be safe and secured.</p>
						</div>
					</div>
					<div class="col-md-4 wow animated fadeInDown" data-wow-duration="1s" data-wow-delay="0.9s">
						<div class="light-box box-hover">
							<h2><span>Email</span></h2>
							<p><a href="#">support@pixlz.in</a><br><a href="#">mano20011998@gmail.com </a></p>
						</div>
					</div>
				</div>
				
				<div class="row">
					<div class="col-md-12">
						<ul class="social-buttons">
							<li><a href="#" class="social-btn"><i class="fa fa-dribbble"></i></a></li>
							<li><a href="#" class="social-btn"><i class="fa fa-twitter"></i></a></li>
							<li><a href="#" class="social-btn"><i class="fa fa-envelope"></i></a></li>
							<li><a href="#" class="social-btn"><i class="fa fa-facebook"></i></a></li>
							<li><a href="#" class="social-btn"><i class="fa fa-skype"></i></a></li>
						</ul>
					</div>
				</div>
			</div>
        </section>
		<!-- /CONTACT -->	

		<!--FOOTER-->	
		<footer>
			<div class="container">
				<div class="row">
					<div class="col-md-6 align-center">
						<ul class="legals">
							
							<li><a target="_blank" href="https://pixlz.in">Made With <3 By Team Pixlz</a></li>
						</ul>
					</div>
				</div>
			</div>
        </footer>
		
		
		<!-- /FOOTER -->
		<!--SCRIPTS-->	
		
		<script type="text/javascript" src="assets/js/jquery-1.11.0.min.js"></script>
		<script type="text/javascript" src="assets/js/jquery-ui-1.10.4.min.js"></script>
		
		<!--VIMEO VIDEO-->     
        <script type="text/javascript" src="assets/js/venobox.js"></script>

        <!--3D GALLERY-->
        <script type="text/javascript" src="assets/js/classie.grid.gallery.js"></script>
		<script type="text/javascript" src="assets/js/modernizr.gridgallery.js"></script>		
		<script type="text/javascript" src="assets/js/cbpGridGallery.js"></script>
 
		<script type="text/javascript" src="assets/js/classie.js" ></script>
		<script type="text/javascript" src="assets/js/modalEffects.js" ></script>
       
	    <script type="text/javascript" src="assets/js/nlform.js" ></script>
		<script>var nlform = new NLForm( document.getElementById( 'nl-form' ) );</script>
        <script type="text/javascript" src="assets/js/bootstrap.min.js" ></script>
        
		<!-- TEAM SLIDER  -->
		<script type="text/javascript" src="assets/js/jquery.flexslider.js" ></script>
		
		<!-- SCHEDULE TABS  -->
        <script type="text/javascript" src="assets/js/modernizr.js" ></script>
		<script type="text/javascript" src="assets/js/cbpFWTabs.js" ></script>		
		
		<!--SPONSOR SLIDER-->
		<script type="text/javascript" src="assets/js/jssor.core.js"></script>
		<script type="text/javascript" src="assets/js/jssor.utils.js"></script>
		<script type="text/javascript" src="assets/js/jssor.slider.js"></script>

		
		<!-- SMOOTH SCROLL  -->
		<script type="text/javascript" src="assets/js/smooth-scroll.js"></script>
		
		<!-- NICE SCROLL  -->
		<script type="text/javascript" src="assets/js/jquery.nicescroll.js"></script>
		
		<!-- SUBSCRIPTION FORM  -->
		<script type="text/javascript" src="assets/js/notifyMe.js"></script>
		
		<script type="text/javascript" src="assets/js/jquery.placeholder.js"></script>
		
		<!-- ANIMATION  -->
		<script type="text/javascript" src="assets/js/wow.min.js"></script>
		<!-- INITIALIZATION  -->
		<script type="text/javascript" src="assets/js/init.js"></script>
		<!--SNOW FALL JS-->
		<script type="text/javascript" src="assets/js/ThreeCanvas.js"></script>
		<script type="text/javascript" src="assets/js/Snow.js"></script>
		<script type="text/javascript" src="assets/js/snowfall-init.js"></script>
		
		
    </body>
</html>