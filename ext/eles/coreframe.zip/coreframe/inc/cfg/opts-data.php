<?php
return array('c_devmode_on' => '1', 'c_favicon_url' => '', 'c_logo_image' => '', 'c_logo_siteinfo' => '1', 'c_copyright_text' => '', 'c_copyright_on' => '1', 'c_layout_mode' => 'contained', 'c_layout_width' => '', 'c_sidebar_on' => '1', 'c_sidebar_pages' => '', 'c_sidebar_pos' => '', 'c_avatars_shape' => '', 'c_avatars_pos' => '', 'c_preloader_on' => '1', 'c_ad_pagetop_on' => '', 'c_ad_pagetop' => '', 'c_ad_pageend_on' => '', 'c_ad_pageend' => '', 'c_ad_widgets_on' => '', 'c_ad_widgets' => '', 'c_nostick_nav' => '', 'c_social_links_on' => '1', 'c_social_links' => 'eyJmYWNlYm9vayI6eyJ0aXRsZSI6IiIsImhyZWYiOiIifSwidHdpdHRlciI6eyJ0aXRsZSI6IiIsImhyZWYiOiIifSwiZ29vZ2xlLXBsdXMiOnsidGl0bGUiOiIiLCJocmVmIjoiIn0sInBpbnRlcmVzdCI6eyJ0aXRsZSI6IiIsImhyZWYiOiIifSwieW91dHViZSI6eyJ0aXRsZSI6IiIsImhyZWYiOiIifSwibGlua2VkaW4iOnsidGl0bGUiOiIiLCJocmVmIjoiIn0sImdpdGh1YiI6eyJ0aXRsZSI6IiIsImhyZWYiOiIifSwiaW5zdGFncmFtIjp7InRpdGxlIjoiIiwiaHJlZiI6IiJ9LCJzdGVhbSI6eyJ0aXRsZSI6IiIsImhyZWYiOiIifSwidHdpdGNoIjp7InRpdGxlIjoiIiwiaHJlZiI6IiJ9fQ==', 'c_menu_items' => '', 'c_style_corners' => '', 'c_style_offset_on' => '1', 'c_style_theme' => 'original', 'c_style_vars' => '', 'c_style_bgim' => '', 'c_style_hero' => '', 'c_style_hero_opacity' => '40', 'c_style_hero_vfx' => '1', 'c_fonts_url' => '', 'c_fonts_size' => '', 'c_fonts_text' => '', 'c_fonts_headers' => '', 'c_code_css' => '', 'c_code_headtag' => '', 'c_code_headtag_on' => '', 'c_code_bodyend' => '', 'c_code_bodyend_on' => '', 'c_footer_widgets' => 'WyJub25lIiwibm9uZSIsIm5vbmUiXQ', 'c_sidebar_widgets' => 'WyJub25lIiwibm9uZSIsIm5vbmUiLCJub25lIiwibm9uZSJd', 'c_wid_adblock_title' => '', 'c_wid_recents_title' => 'Recent Topics', 'c_wid_recents_nr' => '5', 'c_wid_infotabs_title' => '', 'c_wid_forums_title' => 'Forums', 'c_wid_links_title' => 'PhpBB Links', 'c_wid_links_code' => '&lt;ul class=&quot;widget-links&quot;&gt;
  &lt;li&gt;&lt;a href=&quot;https://www.phpbb.com/support/docs/en/3.1/ug/&quot;&gt;
    User Guide
  &lt;/a&gt;&lt;/li&gt;
  &lt;li&gt;&lt;a href=&quot;https://www.phpbb.com/support/&quot;&gt;
    Support Center
  &lt;/a&gt;&lt;/li&gt;
  &lt;li&gt;&lt;a href=&quot;https://www.phpbb.com/community/&quot;&gt;
    Community
  &lt;/a&gt;&lt;/li&gt;
  &lt;li&gt;&lt;a href=&quot;https://www.phpbb.com/languages/&quot;&gt;
    Language Packs
  &lt;/a&gt;&lt;/li&gt;
  &lt;li&gt;&lt;a href=&quot;https://www.phpbb.com/extensions/&quot;&gt;
    Extensions
  &lt;/a&gt;&lt;/li&gt;
&lt;/ul&gt;', 'c_wid_about_title' => 'About Eles', 'c_wid_about_code' => '<strong>ELES</strong> is your <strong>go-tool</strong> for creating awesome communities.
<br><br>
Built on phpBB - the most popular open-source forum software and connected
with the powerful <strong>Coreframe</strong> extension it is sure to provide
you with the right assets to build active bulletin boards that attract
members from all over the world and stimulate user engagement.', 'c_wid_custom1_title' => '', 'c_wid_custom1_code' => '', 'c_wid_custom2_title' => '', 'c_wid_custom2_code' => '', 'c_wid_custom3_title' => '', 'c_wid_custom3_code' => '');